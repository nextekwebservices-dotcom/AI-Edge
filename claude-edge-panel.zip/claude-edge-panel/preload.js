const { contextBridge, ipcRenderer } = require("electron");

function webviewPreloadUrl() {
  return "file://" + __dirname.replace(/\\/g, "/") + "/webview-preload.js";
}

contextBridge.exposeInMainWorld("bridge", {
  // panel
  closePanel: () => ipcRenderer.send("close-panel"),
  getScreenSourceId: () => ipcRenderer.invoke("get-screen-source-id"),
  saveRecording: (arrayBuffer) => ipcRenderer.send("save-recording", arrayBuffer),
  onScreenshotReady: (cb) => ipcRenderer.on("screenshot-ready", cb),
  onRecordingStart: (cb) => ipcRenderer.on("recording-start", cb),
  onRecordingStop: (cb) => ipcRenderer.on("recording-stop", cb),
  notifyClaudeEvent: (payload) => ipcRenderer.send("notify-event", payload),
  getWebviewPreloadPath: () => webviewPreloadUrl(),

  // AI provider (text panel)
  getProviders: () => ipcRenderer.invoke("get-providers"),
  getProviderUrl: () => ipcRenderer.invoke("get-provider-url"),
  getDesktopUA: () => ipcRenderer.invoke("get-desktop-ua"),
  onProviderChanged: (cb) => ipcRenderer.on("provider:changed", (evt, url) => cb(url)),

  // voice provider (separate selection, background session)
  getVoiceProviders: () => ipcRenderer.invoke("get-voice-providers"),
  getVoiceProviderUrl: () => ipcRenderer.invoke("get-voice-provider-url"),
  onVoiceProviderChanged: (cb) => ipcRenderer.on("voice-provider:changed", (evt, url) => cb(url)),
  onVoiceStart: (cb) => ipcRenderer.on("voice:start", cb),
  onVoiceStop: (cb) => ipcRenderer.on("voice:stop", cb),

  // notification circle / border / mic (listened-to, not sent)
  onCircleState: (cb) => ipcRenderer.on("circle:state", (evt, type) => cb(type)),
  onBorderShow: (cb) => ipcRenderer.on("border:show", (evt, payload) => cb(payload)),
  onMicActive: (cb) => ipcRenderer.on("mic:active", (evt, active) => cb(active)),

  // reposition workflow (Settings button starts it, tick button ends it)
  startReposition: (id) => ipcRenderer.send("start-reposition", id),
  confirmReposition: () => ipcRenderer.send("confirm-reposition"),

  // settings (shared)
  getSettings: () => ipcRenderer.invoke("settings:get"),
  updateSettings: (patch) => ipcRenderer.send("settings:update", patch),
  onSettingsChanged: (cb) => ipcRenderer.on("settings:changed", (evt, cfg) => cb(cfg)),
  drawPanelArea: () => ipcRenderer.send("settings:draw-panel-area"),
  resetPanelBounds: () => ipcRenderer.send("settings:reset-panel-bounds"),
  closeSettings: () => ipcRenderer.send("settings:close"),
  snapTabEdge: (edge) => ipcRenderer.send("tab-snap-edge", edge),

  // overlay
  submitOverlayRect: (rect) => ipcRenderer.send("overlay:rect-drawn", rect),
  cancelOverlay: () => ipcRenderer.send("overlay:cancel"),
});
