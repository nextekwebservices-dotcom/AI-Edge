const {
  app,
  BrowserWindow,
  screen,
  ipcMain,
  desktopCapturer,
  clipboard,
  Notification,
  session,
} = require("electron");
const path = require("path");
const fs = require("fs");
const { uIOhook, UiohookKey } = require("uiohook-napi");

// ---------- constants ----------
const TAB_WIN_W = 160;
const TAB_WIN_H = 440;
const PANEL_W_DEFAULT = 380;
const CIRCLE_SIZE = 56;
const CIRCLE_PAD = 40;
const CIRCLE_WIN = CIRCLE_SIZE + CIRCLE_PAD;
const MIC_SIZE = 46;
const MIC_PAD = 40;
const MIC_WIN = MIC_SIZE + MIC_PAD;
const TICK_SIZE = 34;
const HOLD_THRESHOLD_MS = 500;
const TAP_GAP_MS = 350;
const MIN_PANEL_SIZE = 200;

const SETTINGS_PATH = path.join(
  app.getPath("userData"),
  "claude-edge-panel-settings.json"
);

const AI_PROVIDERS = [
  { id: "claude", name: "Claude", url: "https://claude.ai/new" },
  { id: "chatgpt", name: "ChatGPT", url: "https://chatgpt.com/" },
  { id: "gemini", name: "Google Gemini", url: "https://gemini.google.com/app" },
  { id: "perplexity", name: "Perplexity AI", url: "https://www.perplexity.ai/" },
];

// Voice is a separate selection from the text panel above, per your request.
// URLs verified as of this build — Hume and Sesame in particular are
// research/demo-style products and may change their public demo URL over
// time more readily than the big consumer chat apps do.
const VOICE_PROVIDERS = [
  { id: "chatgpt-voice", name: "ChatGPT Advanced Voice", url: "https://chatgpt.com/" },
  { id: "gemini-live", name: "Gemini Live", url: "https://gemini.google.com/app" },
  { id: "hume", name: "Hume AI", url: "https://app.hume.ai/" },
  { id: "grok", name: "Grok 3", url: "https://grok.com/" },
  { id: "sesame", name: "Sesame AI", url: "https://www.sesame.com/" },
];

function providerUrl(id) {
  const p = AI_PROVIDERS.find((p) => p.id === id);
  return p ? p.url : AI_PROVIDERS[0].url;
}
function voiceProviderUrl(id) {
  const p = VOICE_PROVIDERS.find((p) => p.id === id);
  return p ? p.url : VOICE_PROVIDERS[0].url;
}

// A standard desktop-Chrome UA. Several of these sites detect and block
// "unrecognized" embedded browsers (Google's sign-in in particular does
// this on purpose) — this doesn't guarantee every provider will load, but
// it clears the most common, blunt check.
const DESKTOP_UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36";

// Bump this whenever a change to window sizes/positioning math would make
// old saved coordinates (tabX/tabY/micX/micY/panelBounds) land somewhere
// wrong. Settings live in %APPDATA% and persist across every folder/zip you
// download, so without this, a coordinate saved under an older layout can
// silently misplace things under a newer one — this is what caused the
// "floating" tab position.
const CONFIG_VERSION = 2;
const GEOMETRY_FIELDS = ["tabX", "tabY", "tabDock", "micX", "micY", "panelBounds"];

const DEFAULT_CONFIG = {
  configVersion: CONFIG_VERSION,
  style: "glass",
  tabColor: "#8CA0FF",
  shadowColor: "#3C50C8",
  shadowIntensity: 60,
  tabShape: "pill",
  tabScale: 1,
  tabDock: "right",
  tabX: null,
  tabY: null,
  panelEdge: "right",
  panelBounds: null,
  aiProvider: "claude",
  voiceProvider: "chatgpt-voice",
  notifyColor: "#3DDC84",
  questionColor: "#FFB020",
  recordingColor: "#FF3B3B",
  listeningColor: "#4FD3FF",
  micColor: "#8CA0FF",
  micEnabled: false,
  micX: null,
  micY: null,
};

let config = { ...DEFAULT_CONFIG };

function loadConfig() {
  try {
    const raw = fs.readFileSync(SETTINGS_PATH, "utf-8");
    const saved = JSON.parse(raw);
    config = { ...DEFAULT_CONFIG, ...saved };
    if (saved.configVersion !== CONFIG_VERSION) {
      // Layout math changed since this was saved — drop just the
      // position/size fields back to defaults, keep every cosmetic
      // preference (colours, style, shape, providers, etc.) intact.
      for (const field of GEOMETRY_FIELDS) config[field] = DEFAULT_CONFIG[field];
      config.configVersion = CONFIG_VERSION;
      saveConfig();
    }
  } catch {
    config = { ...DEFAULT_CONFIG };
  }
}

function saveConfig() {
  try {
    fs.mkdirSync(path.dirname(SETTINGS_PATH), { recursive: true });
    fs.writeFileSync(SETTINGS_PATH, JSON.stringify(config, null, 2));
  } catch (err) {
    console.error("Failed to save settings:", err);
  }
}

function broadcastSettings() {
  for (const w of [tabWin, panelWin, settingsWin, circleWin, micWin, voiceWin]) {
    if (w && !w.isDestroyed()) w.webContents.send("settings:changed", config);
  }
}

// ---------- window refs / state ----------
let tabWin = null;
let panelWin = null;
let settingsWin = null;
let overlayWin = null;
let borderWin = null;
let circleWin = null;
let micWin = null;
let voiceWin = null;
let tickWin = null;

let isOpen = false;
let isVoiceActive = false;
let animating = false;

let homeDownAt = 0;
let holdTimer = null;
let isRecording = false;

let tapCount = 0;
let tapResetTimer = null;
let transientBorderTimer = null;

// global drag state (tab or mic — whichever was clicked)
let activeDrag = null; // {id, win, origin:{x,y,width,height}, start:{x,y}, moved}
// which element (if any) is currently in a "drag to reposition, confirm with
// the tick button" session — started from a Settings button, not by default
let repositionTarget = null; // null | "tab" | "mic"

function getWorkArea() {
  return screen.getPrimaryDisplay().workArea;
}

function notify(title, body) {
  if (Notification.isSupported()) {
    new Notification({ title, body, silent: true }).show();
  }
}

const TRANSPARENT_BG = "#00000000";
const COMMON_WEB_PREFS = {
  preload: path.join(__dirname, "preload.js"),
  contextIsolation: true,
  nodeIntegration: false,
  sandbox: false,
};

// ---------- layout math ----------
function computeTabBounds() {
  const area = getWorkArea();
  if (config.tabX != null && config.tabY != null) {
    return { x: Math.round(config.tabX), y: Math.round(config.tabY), width: TAB_WIN_W, height: TAB_WIN_H };
  }
  const x = area.x + area.width - TAB_WIN_W;
  const y = area.y + (area.height - TAB_WIN_H) / 2;
  return { x: Math.round(x), y: Math.round(y), width: TAB_WIN_W, height: TAB_WIN_H };
}

function computeMicBounds() {
  const area = getWorkArea();
  if (config.micX != null && config.micY != null) {
    return { x: Math.round(config.micX), y: Math.round(config.micY), width: MIC_WIN, height: MIC_WIN };
  }
  return { x: Math.round(area.x + 4), y: Math.round(area.y + 4), width: MIC_WIN, height: MIC_WIN };
}

function computeCircleBounds() {
  const area = getWorkArea();
  return {
    x: Math.round(area.x + (area.width - CIRCLE_WIN) / 2),
    y: Math.round(area.y + 2),
    width: CIRCLE_WIN,
    height: CIRCLE_WIN,
  };
}

function computeTickBounds(targetWin) {
  const b = targetWin.getBounds();
  return {
    x: Math.round(b.x + b.width - TICK_SIZE / 2),
    y: Math.round(b.y + b.height - TICK_SIZE / 2),
    width: TICK_SIZE,
    height: TICK_SIZE,
  };
}

function computeDefaultPanelTargets() {
  const area = getWorkArea();
  if (config.panelEdge === "right") {
    return {
      closed: { x: area.x + area.width, y: area.y, width: PANEL_W_DEFAULT, height: area.height },
      open: { x: area.x + area.width - PANEL_W_DEFAULT, y: area.y, width: PANEL_W_DEFAULT, height: area.height },
    };
  }
  return {
    closed: { x: area.x - PANEL_W_DEFAULT, y: area.y, width: PANEL_W_DEFAULT, height: area.height },
    open: { x: area.x, y: area.y, width: PANEL_W_DEFAULT, height: area.height },
  };
}

function isCustomPanel() {
  return !!config.panelBounds;
}

// ---------- window creation ----------
function createTabWindow() {
  tabWin = new BrowserWindow({
    ...computeTabBounds(),
    frame: false,
    transparent: true,
    backgroundColor: TRANSPARENT_BG,
    resizable: false,
    movable: false,
    hasShadow: false,
    alwaysOnTop: true,
    skipTaskbar: true,
    focusable: false,
    webPreferences: COMMON_WEB_PREFS,
  });
  tabWin.setAlwaysOnTop(true, "screen-saver");
  tabWin.setVisibleOnAllWorkspaces(true, { visibleOnFullScreen: true });
  tabWin.loadFile("tab.html");
  if (!app.isPackaged) tabWin.webContents.openDevTools({ mode: "detach" });
}

function createPanelWindow() {
  const targets = computeDefaultPanelTargets();
  const startBounds = isCustomPanel() ? config.panelBounds : targets.closed;

  panelWin = new BrowserWindow({
    ...startBounds,
    frame: false,
    transparent: true,
    backgroundColor: TRANSPARENT_BG,
    resizable: false,
    movable: false,
    hasShadow: false,
    alwaysOnTop: true,
    skipTaskbar: true,
    show: !isCustomPanel(),
    webPreferences: { ...COMMON_WEB_PREFS, webviewTag: true },
  });
  panelWin.setAlwaysOnTop(true, "screen-saver");
  panelWin.setVisibleOnAllWorkspaces(true, { visibleOnFullScreen: true });
  if (isCustomPanel()) panelWin.setOpacity(0);
  panelWin.loadFile("index.html");
}

function createCircleWindow() {
  circleWin = new BrowserWindow({
    ...computeCircleBounds(),
    frame: false,
    transparent: true,
    backgroundColor: TRANSPARENT_BG,
    resizable: false,
    movable: false,
    hasShadow: false,
    alwaysOnTop: true,
    skipTaskbar: true,
    focusable: false,
    webPreferences: COMMON_WEB_PREFS,
  });
  circleWin.setAlwaysOnTop(true, "screen-saver");
  circleWin.setIgnoreMouseEvents(true);
  circleWin.setVisibleOnAllWorkspaces(true, { visibleOnFullScreen: true });
  circleWin.setOpacity(0); // hidden until listening or a question is pending
  circleWin.loadFile("circle.html");
}

function createMicWindow() {
  micWin = new BrowserWindow({
    ...computeMicBounds(),
    frame: false,
    transparent: true,
    backgroundColor: TRANSPARENT_BG,
    resizable: false,
    movable: false,
    hasShadow: false,
    alwaysOnTop: true,
    skipTaskbar: true,
    focusable: false,
    show: false,
    webPreferences: COMMON_WEB_PREFS,
  });
  micWin.setAlwaysOnTop(true, "screen-saver");
  micWin.setVisibleOnAllWorkspaces(true, { visibleOnFullScreen: true });
  micWin.loadFile("mic.html");
}

// The voice webview runs entirely in the background — it's never shown.
// Its size/position don't matter for anything the user sees; some pages
// just render more reliably with a real, non-zero viewport.
function createVoiceWindow() {
  voiceWin = new BrowserWindow({
    x: -10000,
    y: -10000,
    width: 480,
    height: 760,
    frame: false,
    transparent: true,
    backgroundColor: TRANSPARENT_BG,
    resizable: false,
    movable: false,
    hasShadow: false,
    skipTaskbar: true,
    show: false,
    webPreferences: { ...COMMON_WEB_PREFS, webviewTag: true },
  });
  voiceWin.loadFile("voice.html");
}

function createBorderWindow() {
  const area = screen.getPrimaryDisplay().bounds;
  borderWin = new BrowserWindow({
    x: area.x,
    y: area.y,
    width: area.width,
    height: area.height,
    frame: false,
    transparent: true,
    backgroundColor: TRANSPARENT_BG,
    resizable: false,
    alwaysOnTop: true,
    skipTaskbar: true,
    focusable: false,
    webPreferences: COMMON_WEB_PREFS,
  });
  borderWin.setAlwaysOnTop(true, "screen-saver");
  borderWin.setIgnoreMouseEvents(true, { forward: true });
  borderWin.setVisibleOnAllWorkspaces(true, { visibleOnFullScreen: true });
  borderWin.setOpacity(0);
  borderWin.loadFile("border.html");
}

function createTickWindow() {
  tickWin = new BrowserWindow({
    x: -10000,
    y: -10000,
    width: TICK_SIZE,
    height: TICK_SIZE,
    frame: false,
    transparent: true,
    backgroundColor: TRANSPARENT_BG,
    resizable: false,
    movable: false,
    hasShadow: false,
    alwaysOnTop: true,
    skipTaskbar: true,
    focusable: false,
    show: false,
    webPreferences: COMMON_WEB_PREFS,
  });
  tickWin.setAlwaysOnTop(true, "screen-saver");
  tickWin.setVisibleOnAllWorkspaces(true, { visibleOnFullScreen: true });
  tickWin.loadFile("tick.html");
}

function createSettingsWindow() {
  if (settingsWin && !settingsWin.isDestroyed()) {
    settingsWin.show();
    settingsWin.focus();
    return;
  }
  const area = getWorkArea();
  const w = 440;
  const h = 720;
  settingsWin = new BrowserWindow({
    width: w,
    height: h,
    x: Math.round(area.x + (area.width - w) / 2),
    y: Math.round(area.y + (area.height - h) / 2),
    frame: false,
    transparent: true,
    backgroundColor: TRANSPARENT_BG,
    resizable: false,
    alwaysOnTop: true,
    skipTaskbar: true,
    webPreferences: COMMON_WEB_PREFS,
  });
  settingsWin.loadFile("settings.html");
  if (!app.isPackaged) settingsWin.webContents.openDevTools({ mode: "detach" });
  settingsWin.on("closed", () => {
    settingsWin = null;
  });
}

function createOverlayWindow(onRect) {
  const area = screen.getPrimaryDisplay().bounds;
  overlayWin = new BrowserWindow({
    x: area.x,
    y: area.y,
    width: area.width,
    height: area.height,
    frame: false,
    transparent: true,
    backgroundColor: TRANSPARENT_BG,
    alwaysOnTop: true,
    skipTaskbar: true,
    resizable: false,
    fullscreenable: false,
    webPreferences: COMMON_WEB_PREFS,
  });
  overlayWin.setAlwaysOnTop(true, "screen-saver");
  overlayWin.loadFile("overlay.html");

  const cleanup = () => {
    if (overlayWin && !overlayWin.isDestroyed()) overlayWin.close();
    overlayWin = null;
  };

  ipcMain.once("overlay:rect-drawn", (evt, rect) => {
    onRect({
      x: Math.round(area.x + rect.x),
      y: Math.round(area.y + rect.y),
      width: Math.max(MIN_PANEL_SIZE, Math.round(rect.width)),
      height: Math.max(MIN_PANEL_SIZE, Math.round(rect.height)),
    });
    cleanup();
  });
  ipcMain.once("overlay:cancel", cleanup);
}

// ---------- slide / fade animation ----------
function animateBounds(win, targetX, durationMs, onDone) {
  if (!win || win.isDestroyed()) return;
  animating = true;
  const area = getWorkArea();
  const start = win.getBounds();
  const distance = targetX - start.x;
  const startTime = Date.now();

  function step() {
    if (!win || win.isDestroyed()) return;
    const t = Math.min(1, (Date.now() - startTime) / durationMs);
    const eased = 1 - Math.pow(1 - t, 3);
    const x = Math.round(start.x + distance * eased);
    win.setBounds({ x, y: area.y, width: start.width, height: area.height });
    if (t < 1) setImmediate(step);
    else {
      animating = false;
      if (onDone) onDone();
    }
  }
  step();
}

function animateOpacity(win, from, to, durationMs, onDone) {
  if (!win || win.isDestroyed()) return;
  const startTime = Date.now();
  win.setOpacity(from);

  function step() {
    if (!win || win.isDestroyed()) return;
    const t = Math.min(1, (Date.now() - startTime) / durationMs);
    win.setOpacity(from + (to - from) * t);
    if (t < 1) setImmediate(step);
    else if (onDone) onDone();
  }
  step();
}

// ---------- open / close: main chat panel ----------
function openPanel() {
  if (animating || isOpen || !panelWin || panelWin.isDestroyed()) return;
  isOpen = true;
  updateCircleState();
  if (isCustomPanel()) {
    panelWin.setBounds(config.panelBounds);
    panelWin.show();
    animateOpacity(panelWin, 0, 1, 200);
  } else {
    const targets = computeDefaultPanelTargets();
    animating = true;
    animateBounds(panelWin, targets.open.x, 220);
  }
}

function closePanel() {
  if (animating || !isOpen || !panelWin || panelWin.isDestroyed()) return;
  isOpen = false;
  if (isCustomPanel()) {
    animateOpacity(panelWin, 1, 0, 200, () => panelWin.hide());
  } else {
    const targets = computeDefaultPanelTargets();
    animating = true;
    animateBounds(panelWin, targets.closed.x, 220);
  }
}

function togglePanel() {
  if (isOpen) closePanel();
  else openPanel();
}

// ---------- voice session (background — no visible window) ----------
let voicePendingQuestion = false; // tracked separately from "listening"

function toggleVoiceSession() {
  if (!voiceWin || voiceWin.isDestroyed()) return;
  isVoiceActive = !isVoiceActive;
  voiceWin.webContents.send(isVoiceActive ? "voice:start" : "voice:stop");
  if (micWin && !micWin.isDestroyed()) micWin.webContents.send("mic:active", isVoiceActive);
  updateCircleState();
}

// ---------- screenshot ----------
async function takeScreenshot() {
  try {
    const primary = screen.getPrimaryDisplay();
    const { width, height } = primary.size;
    const scaleFactor = primary.scaleFactor || 1;

    const sources = await desktopCapturer.getSources({
      types: ["screen"],
      thumbnailSize: {
        width: Math.round(width * scaleFactor),
        height: Math.round(height * scaleFactor),
      },
    });
    if (!sources.length) return;

    clipboard.writeImage(sources[0].thumbnail);

    if (!isOpen) openPanel();
    if (panelWin && !panelWin.isDestroyed()) {
      panelWin.show();
      panelWin.focus();
      panelWin.moveTop();
    }

    setTimeout(() => {
      if (panelWin && !panelWin.isDestroyed())
        panelWin.webContents.send("screenshot-ready");
    }, 120);

    notify("Screenshot copied", "Pasting it into the chat…");
  } catch (err) {
    console.error("Screenshot failed:", err);
  }
}

// ---------- recording (also drives the persistent border) ----------
function startRecording() {
  isRecording = true;
  if (panelWin && !panelWin.isDestroyed()) panelWin.webContents.send("recording-start");
  showRecordingBorder();
  notify("Recording started", "Release Home to stop.");
}

function stopRecording() {
  isRecording = false;
  if (panelWin && !panelWin.isDestroyed()) panelWin.webContents.send("recording-stop");
  hideBorder();
}

// ---------- notification border + status circle ----------
function showRecordingBorder() {
  clearTimeout(transientBorderTimer);
  if (borderWin && !borderWin.isDestroyed()) {
    borderWin.webContents.send("border:show", { color: config.recordingColor });
    animateOpacity(borderWin, borderWin.getOpacity(), 1, 200);
  }
}

function hideBorder() {
  if (borderWin && !borderWin.isDestroyed()) {
    animateOpacity(borderWin, borderWin.getOpacity(), 0, 250);
  }
}

function showTransientBorder(type) {
  if (isRecording) return;
  const color = type === "question" ? config.questionColor : config.notifyColor;
  if (borderWin && !borderWin.isDestroyed()) {
    borderWin.webContents.send("border:show", { color });
    animateOpacity(borderWin, borderWin.getOpacity(), 1, 200);
  }
  clearTimeout(transientBorderTimer);
  transientBorderTimer = setTimeout(() => hideBorder(), 2600);
}

// The top-centre orb has three effective states: hidden, listening (voice
// session active — takes priority), or question (a text question pending).
// Opening the panel or ending the voice session re-evaluates this.
function updateCircleState() {
  if (!circleWin || circleWin.isDestroyed()) return;
  let state = "hidden";
  if (isVoiceActive) state = "listening";
  else if (voicePendingQuestion && !isOpen) state = "question";

  circleWin.webContents.send("circle:state", state);
  animateOpacity(circleWin, circleWin.getOpacity(), state === "hidden" ? 0 : 1, 200);
}

// ---------- IPC ----------
ipcMain.handle("get-screen-source-id", async () => {
  const sources = await desktopCapturer.getSources({ types: ["screen"] });
  return sources.length ? sources[0].id : null;
});

ipcMain.handle("get-providers", () => AI_PROVIDERS);
ipcMain.handle("get-provider-url", () => providerUrl(config.aiProvider));
ipcMain.handle("get-voice-providers", () => VOICE_PROVIDERS);
ipcMain.handle("get-voice-provider-url", () => voiceProviderUrl(config.voiceProvider));
ipcMain.handle("get-desktop-ua", () => DESKTOP_UA);

ipcMain.on("save-recording", (evt, buffer) => {
  const dir = path.join(app.getPath("videos"), "ClaudeEdgePanel");
  fs.mkdirSync(dir, { recursive: true });
  const file = path.join(dir, `recording-${Date.now()}.webm`);
  fs.writeFile(file, Buffer.from(buffer), (err) => {
    if (err) {
      console.error("Failed to save recording:", err);
      notify("Recording failed to save", err.message);
    } else {
      notify("Recording saved", file);
    }
  });
});

ipcMain.on("close-panel", () => closePanel());
ipcMain.on("mic-clicked", () => toggleVoiceSession());

ipcMain.on("notify-event", (evt, payload) => {
  if (payload.type === "question") {
    voicePendingQuestion = true;
    if (!isOpen) {
      showTransientBorder("question");
      updateCircleState();
    }
  } else if (payload.type === "response") {
    voicePendingQuestion = false;
    if (!isOpen) showTransientBorder("response");
    updateCircleState();
  }
});

ipcMain.handle("settings:get", () => config);

ipcMain.on("settings:update", (evt, patch) => {
  const providerChanged = "aiProvider" in patch && patch.aiProvider !== config.aiProvider;
  const voiceProviderChanged =
    "voiceProvider" in patch && patch.voiceProvider !== config.voiceProvider;
  const panelEdgeChanged = "panelEdge" in patch && patch.panelEdge !== config.panelEdge;
  const micToggled = "micEnabled" in patch && patch.micEnabled !== config.micEnabled;

  config = { ...config, ...patch };
  saveConfig();
  broadcastSettings();

  if (panelEdgeChanged && !isCustomPanel() && panelWin && !panelWin.isDestroyed()) {
    const targets = computeDefaultPanelTargets();
    panelWin.setBounds(isOpen ? targets.open : targets.closed);
  }

  if (providerChanged) {
    const url = providerUrl(config.aiProvider);
    if (panelWin && !panelWin.isDestroyed()) panelWin.webContents.send("provider:changed", url);
  }

  if (voiceProviderChanged) {
    const url = voiceProviderUrl(config.voiceProvider);
    if (voiceWin && !voiceWin.isDestroyed()) voiceWin.webContents.send("voice-provider:changed", url);
  }

  if (micToggled && micWin && !micWin.isDestroyed()) {
    if (config.micEnabled) {
      micWin.setBounds(computeMicBounds());
      micWin.show();
    } else {
      micWin.hide();
      if (isVoiceActive) toggleVoiceSession();
    }
  }
});

ipcMain.on("tab-snap-edge", (evt, edge) => {
  if (!tabWin || tabWin.isDestroyed()) return;
  const area = getWorkArea();
  const b = tabWin.getBounds();
  let x = b.x;
  let y = b.y;
  if (edge === "left") x = area.x;
  else if (edge === "right") x = area.x + area.width - TAB_WIN_W;
  else if (edge === "top") y = area.y;
  else if (edge === "bottom") y = area.y + area.height - TAB_WIN_H;
  x = Math.max(area.x - TAB_WIN_W / 2, Math.min(area.x + area.width - TAB_WIN_W / 2, x));
  y = Math.max(area.y - TAB_WIN_H / 2, Math.min(area.y + area.height - TAB_WIN_H / 2, y));
  tabWin.setBounds({ x: Math.round(x), y: Math.round(y), width: TAB_WIN_W, height: TAB_WIN_H });
  config.tabDock = edge;
  config.tabX = Math.round(x);
  config.tabY = Math.round(y);
  saveConfig();
  broadcastSettings();
});

ipcMain.on("settings:draw-panel-area", () => {
  if (settingsWin && !settingsWin.isDestroyed()) settingsWin.hide();
  createOverlayWindow((rect) => {
    config.panelBounds = rect;
    saveConfig();
    if (panelWin && !panelWin.isDestroyed()) {
      panelWin.setBounds(rect);
      isOpen = true;
      panelWin.show();
      animateOpacity(panelWin, panelWin.getOpacity(), 1, 200);
    }
    broadcastSettings();
    if (settingsWin && !settingsWin.isDestroyed()) settingsWin.show();
  });
});

ipcMain.on("settings:reset-panel-bounds", () => {
  config.panelBounds = null;
  saveConfig();
  if (panelWin && !panelWin.isDestroyed()) {
    const targets = computeDefaultPanelTargets();
    panelWin.setOpacity(1);
    panelWin.setBounds(isOpen ? targets.open : targets.closed);
    if (!isOpen) panelWin.show();
  }
  broadcastSettings();
});

ipcMain.on("settings:close", () => {
  if (settingsWin && !settingsWin.isDestroyed()) settingsWin.close();
});

// ---------- reposition workflow: button in Settings starts it, tick button ends it ----------
function targetWindowFor(id) {
  return id === "tab" ? tabWin : id === "mic" ? micWin : null;
}

function startReposition(id) {
  const win = targetWindowFor(id);
  if (!win || win.isDestroyed()) return;
  if (id === "mic" && !config.micEnabled) return; // nothing to move
  repositionTarget = id;
  if (settingsWin && !settingsWin.isDestroyed()) settingsWin.hide();
  if (tickWin) {
    tickWin.setBounds(computeTickBounds(win));
    tickWin.show();
    tickWin.moveTop();
  }
}

function confirmReposition() {
  repositionTarget = null;
  if (tickWin) tickWin.hide();
  if (settingsWin && !settingsWin.isDestroyed()) settingsWin.show();
}

ipcMain.on("start-reposition", (evt, id) => startReposition(id));
ipcMain.on("confirm-reposition", () => confirmReposition());

// ---------- global mouse: drag-or-click for the tab and the mic button ----------
function pointInBounds(p, b) {
  return p.x >= b.x && p.x <= b.x + b.width && p.y >= b.y && p.y <= b.y + b.height;
}

function setupGlobalMouse() {
  uIOhook.on("mousedown", (e) => {
    if (activeDrag) return;
    const p = { x: e.x, y: e.y };

    if (tickWin && tickWin.isVisible() && pointInBounds(p, tickWin.getBounds())) {
      confirmReposition();
      return;
    }
    if (tabWin && !tabWin.isDestroyed() && pointInBounds(p, tabWin.getBounds())) {
      activeDrag = { id: "tab", win: tabWin, origin: tabWin.getBounds(), start: p, moved: false };
    } else if (
      config.micEnabled &&
      micWin &&
      !micWin.isDestroyed() &&
      pointInBounds(p, micWin.getBounds())
    ) {
      activeDrag = { id: "mic", win: micWin, origin: micWin.getBounds(), start: p, moved: false };
    }
  });

  uIOhook.on("mousemove", (e) => {
    if (!activeDrag || repositionTarget !== activeDrag.id) return;
    const dx = e.x - activeDrag.start.x;
    const dy = e.y - activeDrag.start.y;
    if (!activeDrag.moved && (Math.abs(dx) > 4 || Math.abs(dy) > 4)) activeDrag.moved = true;
    if (!activeDrag.moved) return;

    const area = getWorkArea();
    const { width, height } = activeDrag.origin;
    let x = activeDrag.origin.x + dx;
    let y = activeDrag.origin.y + dy;
    x = Math.max(area.x - width / 2, Math.min(area.x + area.width - width / 2, x));
    y = Math.max(area.y - height / 2, Math.min(area.y + area.height - height / 2, y));
    activeDrag.win.setBounds({ x: Math.round(x), y: Math.round(y), width, height });
    if (tickWin) tickWin.setBounds(computeTickBounds(activeDrag.win));
  });

  uIOhook.on("mouseup", () => {
    if (!activeDrag) return;
    const { id, win, moved } = activeDrag;
    activeDrag = null;

    if (repositionTarget !== id) {
      // Not in a reposition session for this element — a plain click.
      if (!moved) {
        if (id === "tab") togglePanel();
        else if (id === "mic") toggleVoiceSession();
      }
      return;
    }

    // In a reposition session: dragging just updates the saved position;
    // the session itself only ends via the tick button.
    if (moved) {
      const b = win.getBounds();
      if (id === "tab") {
        config.tabX = b.x;
        config.tabY = b.y;
      } else if (id === "mic") {
        config.micX = b.x;
        config.micY = b.y;
      }
      saveConfig();
      broadcastSettings();
    }
  });
}

// ---------- global Home key: tap = screenshot, triple-tap = settings, hold = record ----------
function onQualifyingTap() {
  tapCount++;
  clearTimeout(tapResetTimer);

  if (tapCount >= 3) {
    tapCount = 0;
    createSettingsWindow();
    return;
  }

  tapResetTimer = setTimeout(() => {
    if (tapCount === 1) takeScreenshot();
    tapCount = 0;
  }, TAP_GAP_MS);
}

function setupGlobalHotkey() {
  uIOhook.on("keydown", (e) => {
    if (e.keycode !== UiohookKey.Home) return;
    if (homeDownAt !== 0) return;
    homeDownAt = Date.now();
    holdTimer = setTimeout(() => {
      if (homeDownAt !== 0) startRecording();
    }, HOLD_THRESHOLD_MS);
  });

  uIOhook.on("keyup", (e) => {
    if (e.keycode !== UiohookKey.Home) return;
    const heldFor = Date.now() - homeDownAt;
    homeDownAt = 0;
    clearTimeout(holdTimer);

    if (isRecording) {
      stopRecording();
    } else if (heldFor < HOLD_THRESHOLD_MS) {
      onQualifyingTap();
    }
  });
}

app.whenReady().then(() => {
  loadConfig();

  const webviewSession = session.fromPartition("persist:claude-edge-panel");
  webviewSession.setPermissionRequestHandler((webContents, permission, callback) => {
    callback(permission === "media");
  });

  createTabWindow();
  createPanelWindow();
  createCircleWindow();
  createMicWindow();
  createVoiceWindow();
  createBorderWindow();
  createTickWindow();
  setupGlobalHotkey();
  setupGlobalMouse();
  uIOhook.start();

  if (!app.isPackaged) return;
  app.setLoginItemSettings({ openAtLogin: true, path: process.execPath });
});

app.on("window-all-closed", () => {
  uIOhook.stop();
  app.quit();
});
