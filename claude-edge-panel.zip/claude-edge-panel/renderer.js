const webview = document.getElementById("claude-view");
const recIndicator = document.getElementById("rec-indicator");

// ---------- load the selected AI provider with our activity-detection preload ----------
webview.setAttribute("preload", window.bridge.getWebviewPreloadPath());
window.bridge.getDesktopUA().then((ua) => webview.setAttribute("useragent", ua));
window.bridge.getProviderUrl().then((url) => {
  webview.src = url;
});
window.bridge.onProviderChanged((url) => {
  webview.src = url;
});

webview.addEventListener("ipc-message", (event) => {
  if (event.channel === "claude-activity") {
    window.bridge.notifyClaudeEvent(event.args[0]);
  }
});

webview.addEventListener("did-fail-load", (e) => {
  console.warn("Chat page failed to load:", e.errorDescription);
});

// ---------- settings ----------
function hexToRgba(hex, a) {
  const h = (hex || "#8CA0FF").replace("#", "");
  const r = parseInt(h.slice(0, 2), 16);
  const g = parseInt(h.slice(2, 4), 16);
  const b = parseInt(h.slice(4, 6), 16);
  return `rgba(${r},${g},${b},${a})`;
}

function lighten(hex, amount) {
  const h = (hex || "#8CA0FF").replace("#", "");
  const r = parseInt(h.slice(0, 2), 16);
  const g = parseInt(h.slice(2, 4), 16);
  const b = parseInt(h.slice(4, 6), 16);
  const mix = (c) => Math.round(c + (255 - c) * amount);
  return `rgb(${mix(r)},${mix(g)},${mix(b)})`;
}

function applySettings(cfg) {
  document.body.classList.toggle("solid", cfg.style === "solid");
  const root = document.documentElement.style;
  root.setProperty("--tint-12", hexToRgba(cfg.tabColor, 0.12));
  root.setProperty("--tint-22", hexToRgba(cfg.tabColor, 0.22));
  root.setProperty("--solid-bg", lighten(cfg.tabColor, 0.08));
  root.setProperty("--shadow-rgba", hexToRgba(cfg.shadowColor, (cfg.shadowIntensity ?? 60) / 100));
}
window.bridge.getSettings().then(applySettings);
window.bridge.onSettingsChanged(applySettings);

// ---------- auto-paste screenshot into the embedded chat ----------
window.bridge.onScreenshotReady(async () => {
  webview.focus();

  const focusScript = `
    (function () {
      const el =
        document.querySelector('div[contenteditable="true"]') ||
        document.querySelector('textarea');
      if (el) {
        el.focus();
        return true;
      }
      return false;
    })();
  `;
  try {
    const focused = await webview.executeJavaScript(focusScript);
    if (focused) {
      webview.paste();
    } else {
      console.warn(
        "Could not find the chat input — screenshot is still on your clipboard, paste manually with Ctrl+V."
      );
    }
  } catch (err) {
    console.error("Auto-paste failed:", err);
  }
});

// ---------- screen recording ----------
let mediaRecorder = null;
let chunks = [];

window.bridge.onRecordingStart(async () => {
  recIndicator.classList.remove("hidden");
  try {
    const sourceId = await window.bridge.getScreenSourceId();
    const stream = await navigator.mediaDevices.getUserMedia({
      audio: false,
      video: {
        mandatory: {
          chromeMediaSource: "desktop",
          chromeMediaSourceId: sourceId,
        },
      },
    });

    chunks = [];
    mediaRecorder = new MediaRecorder(stream, { mimeType: "video/webm; codecs=vp9" });
    mediaRecorder.ondataavailable = (e) => {
      if (e.data.size > 0) chunks.push(e.data);
    };
    mediaRecorder.onstop = async () => {
      stream.getTracks().forEach((t) => t.stop());
      const blob = new Blob(chunks, { type: "video/webm" });
      const buffer = await blob.arrayBuffer();
      window.bridge.saveRecording(buffer);
    };
    mediaRecorder.start();
  } catch (err) {
    console.error("Failed to start recording:", err);
    recIndicator.classList.add("hidden");
  }
});

window.bridge.onRecordingStop(() => {
  recIndicator.classList.add("hidden");
  if (mediaRecorder && mediaRecorder.state !== "inactive") {
    mediaRecorder.stop();
  }
});
