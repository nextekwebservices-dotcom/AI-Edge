// Drag and click are handled globally in the main process — this file only
// applies live settings and the listening/idle visual state.
const mic = document.getElementById("mic");

// Single entry point for the mic's "is voice chat open" visual state.
// A future animation (audio-reactive waveform, etc.) should hook in here
// rather than adding new IPC — this is the one place that knows whether
// we're listening.
function setMicListening(active) {
  mic.classList.toggle("listening", active);
}
window.bridge.onMicActive(setMicListening);

function hexToRgba(hex, a) {
  const h = (hex || "#8CA0FF").replace("#", "");
  const r = parseInt(h.slice(0, 2), 16);
  const g = parseInt(h.slice(2, 4), 16);
  const b = parseInt(h.slice(4, 6), 16);
  return `rgba(${r},${g},${b},${a})`;
}

function applySettings(cfg) {
  document.body.classList.toggle("solid", cfg.style === "solid");
  const root = document.documentElement.style;
  root.setProperty("--tint-40", hexToRgba(cfg.micColor, 0.4));
  root.setProperty("--tint-65", hexToRgba(cfg.micColor, 0.65));
  root.setProperty("--mic-solid", cfg.micColor);
  root.setProperty("--shadow-rgba", hexToRgba(cfg.shadowColor, (cfg.shadowIntensity ?? 60) / 100));
}

window.bridge.getSettings().then(applySettings);
window.bridge.onSettingsChanged(applySettings);
