const styleToggle = document.getElementById("style-toggle");
const shapeGrid = document.getElementById("shape-grid");
const providerGrid = document.getElementById("provider-grid");
const voiceProviderGrid = document.getElementById("voice-provider-grid");
const dockToggle = document.getElementById("dock-toggle");
const panelEdgeToggle = document.getElementById("panel-edge-toggle");
const micToggle = document.getElementById("mic-toggle");
const tabColorInput = document.getElementById("tab-color");
const shadowColorInput = document.getElementById("shadow-color");
const shadowIntensityInput = document.getElementById("shadow-intensity");
const tabScaleInput = document.getElementById("tab-scale");
const listeningColorInput = document.getElementById("listening-color");
const notifyColorInput = document.getElementById("notify-color");
const questionColorInput = document.getElementById("question-color");
const recordingColorInput = document.getElementById("recording-color");
const micColorInput = document.getElementById("mic-color");
const drawBtn = document.getElementById("draw-btn");
const resetBtn = document.getElementById("reset-btn");
const closeBtn = document.getElementById("close-btn");
const moveTabBtn = document.getElementById("move-tab-btn");
const moveMicBtn = document.getElementById("move-mic-btn");

function setActive(container, value) {
  container.querySelectorAll("button").forEach((btn) => {
    btn.classList.toggle("active", btn.dataset.value === value);
  });
}

function renderFromConfig(cfg) {
  setActive(styleToggle, cfg.style);
  setActive(shapeGrid, cfg.tabShape);
  setActive(providerGrid, cfg.aiProvider);
  setActive(voiceProviderGrid, cfg.voiceProvider);
  setActive(dockToggle, cfg.tabDock);
  setActive(panelEdgeToggle, cfg.panelEdge);
  setActive(micToggle, cfg.micEnabled ? "on" : "off");
  tabColorInput.value = cfg.tabColor;
  shadowColorInput.value = cfg.shadowColor;
  shadowIntensityInput.value = cfg.shadowIntensity ?? 60;
  tabScaleInput.value = Math.round((cfg.tabScale ?? 1) * 100);
  listeningColorInput.value = cfg.listeningColor;
  notifyColorInput.value = cfg.notifyColor;
  questionColorInput.value = cfg.questionColor;
  recordingColorInput.value = cfg.recordingColor;
  micColorInput.value = cfg.micColor;
}

function wireSegmented(container, key) {
  container.addEventListener("click", (e) => {
    const btn = e.target.closest("button");
    if (!btn) return;
    setActive(container, btn.dataset.value);
    window.bridge.updateSettings({ [key]: btn.dataset.value });
  });
}

wireSegmented(styleToggle, "style");
wireSegmented(shapeGrid, "tabShape");
wireSegmented(providerGrid, "aiProvider");
wireSegmented(voiceProviderGrid, "voiceProvider");
wireSegmented(panelEdgeToggle, "panelEdge");

dockToggle.addEventListener("click", (e) => {
  const btn = e.target.closest("button");
  if (!btn) return;
  setActive(dockToggle, btn.dataset.value);
  window.bridge.snapTabEdge(btn.dataset.value);
});

micToggle.addEventListener("click", (e) => {
  const btn = e.target.closest("button");
  if (!btn) return;
  setActive(micToggle, btn.dataset.value);
  window.bridge.updateSettings({ micEnabled: btn.dataset.value === "on" });
});

function wireColor(input, key) {
  input.addEventListener("input", () => {
    window.bridge.updateSettings({ [key]: input.value });
  });
}
wireColor(tabColorInput, "tabColor");
wireColor(shadowColorInput, "shadowColor");
wireColor(listeningColorInput, "listeningColor");
wireColor(notifyColorInput, "notifyColor");
wireColor(questionColorInput, "questionColor");
wireColor(recordingColorInput, "recordingColor");
wireColor(micColorInput, "micColor");

shadowIntensityInput.addEventListener("input", () => {
  window.bridge.updateSettings({ shadowIntensity: Number(shadowIntensityInput.value) });
});
tabScaleInput.addEventListener("input", () => {
  window.bridge.updateSettings({ tabScale: Number(tabScaleInput.value) / 100 });
});

drawBtn.addEventListener("click", () => window.bridge.drawPanelArea());
resetBtn.addEventListener("click", () => window.bridge.resetPanelBounds());
closeBtn.addEventListener("click", () => window.bridge.closeSettings());
moveTabBtn.addEventListener("click", () => window.bridge.startReposition("tab"));
moveMicBtn.addEventListener("click", () => window.bridge.startReposition("mic"));

window.bridge.getProviders().then((providers) => {
  providerGrid.innerHTML = "";
  providers.forEach((p) => {
    const btn = document.createElement("button");
    btn.className = "shape-btn";
    btn.dataset.value = p.id;
    btn.textContent = p.name;
    providerGrid.appendChild(btn);
  });
  window.bridge.getSettings().then((cfg) => setActive(providerGrid, cfg.aiProvider));
});

window.bridge.getVoiceProviders().then((providers) => {
  voiceProviderGrid.innerHTML = "";
  providers.forEach((p) => {
    const btn = document.createElement("button");
    btn.className = "shape-btn";
    btn.dataset.value = p.id;
    btn.textContent = p.name;
    voiceProviderGrid.appendChild(btn);
  });
  window.bridge.getSettings().then((cfg) => setActive(voiceProviderGrid, cfg.voiceProvider));
});

window.bridge.getSettings().then(renderFromConfig);
window.bridge.onSettingsChanged(renderFromConfig);
