// Dragging and clicking are handled entirely in the main process (a global
// mouse hook), so this file only has to render the shape from settings.
const glow = document.querySelector(".tab-glow");

function hexToRgba(hex, a) {
  const h = (hex || "#8CA0FF").replace("#", "");
  const r = parseInt(h.slice(0, 2), 16);
  const g = parseInt(h.slice(2, 4), 16);
  const b = parseInt(h.slice(4, 6), 16);
  return `rgba(${r},${g},${b},${a})`;
}

function applySettings(cfg) {
  document.body.classList.toggle("solid", cfg.style === "solid");
  document.body.classList.toggle("dock-top", cfg.tabDock === "top");
  document.body.classList.toggle("dock-bottom", cfg.tabDock === "bottom");

  glow.classList.remove("shape-pill", "shape-circle", "shape-square", "shape-bar");
  glow.classList.add(`shape-${cfg.tabShape || "pill"}`);

  const root = document.documentElement.style;
  root.setProperty("--tint-35", hexToRgba(cfg.tabColor, 0.35));
  root.setProperty("--tint-60", hexToRgba(cfg.tabColor, 0.6));
  root.setProperty("--tab-solid", cfg.tabColor);
  root.setProperty("--shadow-rgba", hexToRgba(cfg.shadowColor, (cfg.shadowIntensity ?? 60) / 100));
  root.setProperty("--tab-scale", (cfg.tabScale ?? 1).toString());
}

window.bridge.getSettings().then(applySettings);
window.bridge.onSettingsChanged(applySettings);
