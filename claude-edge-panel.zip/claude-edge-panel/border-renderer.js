// A bundle of nested, glowing rounded-rect outlines around the screen edge,
// each flowing at a slightly different speed/phase — a "ribbon" rather than
// simple marching-ants dashes. Colour + visibility come from main.
const group = document.getElementById("ribbon-group");
const LINE_COUNT = 6;
const BASE_INSET = 6;
const LINE_GAP = 4;

let lines = [];

function buildLines() {
  group.innerHTML = "";
  lines = [];
  for (let i = 0; i < LINE_COUNT; i++) {
    const inset = BASE_INSET + i * LINE_GAP;
    const rect = document.createElementNS("http://www.w3.org/2000/svg", "rect");
    rect.setAttribute("class", "ribbon-line");
    rect.setAttribute("x", inset);
    rect.setAttribute("y", inset);
    rect.setAttribute("width", Math.max(0, window.innerWidth - inset * 2));
    rect.setAttribute("height", Math.max(0, window.innerHeight - inset * 2));
    rect.setAttribute("rx", 22);
    rect.setAttribute("stroke-width", 2.2 - i * 0.15);
    rect.style.opacity = (0.85 - i * 0.11).toFixed(2);
    const perimeter = 2 * (window.innerWidth + window.innerHeight - 4 * inset);
    const dash = Math.max(20, perimeter * 0.06);
    rect.setAttribute("stroke-dasharray", `${dash} ${dash * 0.7}`);
    const duration = 3.2 + i * 0.5;
    const delay = i * 0.18;
    rect.style.animation = `flow ${duration}s linear ${delay}s infinite`;
    rect.style.setProperty("--dash-len", `-${perimeter}`);
    group.appendChild(rect);
    lines.push(rect);
  }
}

// The dash-offset distance has to be injected per-element (perimeter varies
// by screen size), so the keyframes reference a CSS variable instead of a
// fixed number.
const styleEl = document.createElement("style");
styleEl.textContent = `
  @keyframes flow {
    to { stroke-dashoffset: var(--dash-len); }
  }
`;
document.head.appendChild(styleEl);

buildLines();
window.addEventListener("resize", buildLines);

window.bridge.onBorderShow(({ color }) => {
  document.documentElement.style.setProperty("--border-color", color);
});
