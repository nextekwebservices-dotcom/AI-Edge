// This runs inside the guest page (claude.ai / chatgpt.com / etc via the
// <webview> preload attribute). It's necessarily best-effort: it has to
// guess at each site's DOM structure, so it may miss on some providers or
// break if a site redesigns. When it can't find anything, it just stays
// quiet — nothing else in the app depends on it working.
const { ipcRenderer } = require("electron");

let lastSeenText = "";
let quietTimer = null;

function guessMessageNodes() {
  return Array.from(
    document.querySelectorAll(
      '[data-testid*="message"], [class*="message"], [data-message-author-role]'
    )
  ).filter((el) => (el.innerText || "").trim().length > 0);
}

function checkForCompletion() {
  const nodes = guessMessageNodes();
  if (!nodes.length) return;
  const last = nodes[nodes.length - 1];
  const text = (last.innerText || "").trim();
  if (!text || text === lastSeenText) return;
  lastSeenText = text;

  clearTimeout(quietTimer);
  quietTimer = setTimeout(() => {
    const isQuestion = /[?？]\s*$/.test(text);
    ipcRenderer.sendToHost("claude-activity", {
      type: isQuestion ? "question" : "response",
    });
  }, 900); // wait for streaming to settle before treating it as "finished"
}

window.addEventListener("DOMContentLoaded", () => {
  const observer = new MutationObserver(checkForCompletion);
  observer.observe(document.body, {
    childList: true,
    subtree: true,
    characterData: true,
  });
});
