// This window is never shown — it just hosts the selected voice provider's
// page in the background. Since the user can't see or click anything here
// themselves, starting/stopping the call is attempted for them via a
// best-effort script that looks for a plausible "start/end call" button.
// This is inherently fragile — every provider's page is different, and none
// of this is guaranteed to find the right control. If it can't find
// anything, the page still loads and holds microphone permission; nothing
// else in the app depends on this working.
const webview = document.getElementById("voice-view");

window.bridge.getDesktopUA().then((ua) => webview.setAttribute("useragent", ua));
window.bridge.getVoiceProviderUrl().then((url) => {
  webview.src = url;
});
window.bridge.onVoiceProviderChanged((url) => {
  webview.src = url;
});

const START_KEYWORDS = [
  "start voice",
  "voice mode",
  "start call",
  "advanced voice",
  "live",
  "start conversation",
  "talk to",
  "voice chat",
  "microphone",
  "call",
];
const STOP_KEYWORDS = [
  "end call",
  "end voice",
  "hang up",
  "end conversation",
  "stop",
  "mute",
  "close",
];

function buildClickScript(keywords) {
  return `
    (function() {
      const keywords = ${JSON.stringify(keywords)};
      const candidates = Array.from(document.querySelectorAll('button, [role="button"]'));
      const norm = (s) => (s || "").toLowerCase();
      for (const el of candidates) {
        const label = norm(el.getAttribute("aria-label")) + " " + norm(el.title) + " " + norm(el.innerText);
        if (keywords.some((k) => label.includes(k))) {
          el.click();
          return true;
        }
      }
      return false;
    })();
  `;
}

async function tryClick(keywords, attempts, delayMs) {
  for (let i = 0; i < attempts; i++) {
    try {
      const found = await webview.executeJavaScript(buildClickScript(keywords));
      if (found) return true;
    } catch {
      // page may not be ready yet — just retry
    }
    await new Promise((r) => setTimeout(r, delayMs));
  }
  return false;
}

window.bridge.onVoiceStart(() => {
  tryClick(START_KEYWORDS, 6, 1000).then((found) => {
    if (!found) console.warn("Could not find a voice-start control on this page automatically.");
  });
});

window.bridge.onVoiceStop(() => {
  tryClick(STOP_KEYWORDS, 3, 500).then((found) => {
    if (!found) console.warn("Could not find an end-call control automatically — the session may still be live on the page.");
  });
});
