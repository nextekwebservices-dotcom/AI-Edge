// Animated flowing wave-lines orb, shown only for "listening" (voice active)
// or "question" (AI waiting on the user) — hidden the rest of the time.
// Colour and on/off state come from main; the wave motion itself just runs
// continuously here via requestAnimationFrame.
const wave1 = document.getElementById("wave1");
const wave2 = document.getElementById("wave2");
const wave3 = document.getElementById("wave3");

let phase = 0;
let running = false;
let rafId = null;

function sinePath(amplitude, frequency, phaseOffset, yOffset) {
  const points = [];
  const steps = 28;
  for (let i = 0; i <= steps; i++) {
    const x = (i / steps) * 56;
    const t = (i / steps) * Math.PI * 2 * frequency + phase + phaseOffset;
    const y = yOffset + Math.sin(t) * amplitude;
    points.push(`${i === 0 ? "M" : "L"}${x.toFixed(1)},${y.toFixed(1)}`);
  }
  return points.join(" ");
}

function tick() {
  if (!running) return;
  phase += 0.09;
  wave1.setAttribute("d", sinePath(9, 1.4, 0, 28));
  wave2.setAttribute("d", sinePath(7, 1.9, 1.4, 28));
  wave3.setAttribute("d", sinePath(11, 1.1, 2.6, 28));
  rafId = requestAnimationFrame(tick);
}

function startWaves() {
  if (running) return;
  running = true;
  tick();
}

function stopWaves() {
  running = false;
  if (rafId) cancelAnimationFrame(rafId);
}

function hexToRgb(hex) {
  const h = (hex || "#4FD3FF").replace("#", "");
  return `#${h}`;
}

let currentConfig = null;
let currentState = "hidden";

function applyState(state, cfg) {
  const color = state === "listening" ? cfg.listeningColor : cfg.questionColor;
  document.documentElement.style.setProperty("--orb-color", hexToRgb(color || "#4FD3FF"));
  if (state === "hidden") stopWaves();
  else startWaves();
}

function applySettings(cfg) {
  currentConfig = cfg;
  document.documentElement.style.setProperty("--shadow-rgba", `rgba(60,80,200,${(cfg.shadowIntensity ?? 60) / 100})`);
  applyState(currentState, cfg);
}

window.bridge.onCircleState((state) => {
  currentState = state;
  if (currentConfig) applyState(state, currentConfig);
});

window.bridge.getSettings().then(applySettings);
window.bridge.onSettingsChanged(applySettings);
