const rectEl = document.getElementById("rect");
let startX = 0;
let startY = 0;
let dragging = false;

document.addEventListener("mousedown", (e) => {
  dragging = true;
  startX = e.clientX;
  startY = e.clientY;
  rectEl.style.display = "block";
  rectEl.style.left = `${startX}px`;
  rectEl.style.top = `${startY}px`;
  rectEl.style.width = "0px";
  rectEl.style.height = "0px";
});

document.addEventListener("mousemove", (e) => {
  if (!dragging) return;
  const x = Math.min(startX, e.clientX);
  const y = Math.min(startY, e.clientY);
  const w = Math.abs(e.clientX - startX);
  const h = Math.abs(e.clientY - startY);
  rectEl.style.left = `${x}px`;
  rectEl.style.top = `${y}px`;
  rectEl.style.width = `${w}px`;
  rectEl.style.height = `${h}px`;
});

document.addEventListener("mouseup", (e) => {
  if (!dragging) return;
  dragging = false;
  const x = Math.min(startX, e.clientX);
  const y = Math.min(startY, e.clientY);
  const width = Math.abs(e.clientX - startX);
  const height = Math.abs(e.clientY - startY);

  if (width < 20 || height < 20) {
    // treat as an accidental click, not a real drag
    rectEl.style.display = "none";
    return;
  }
  window.bridge.submitOverlayRect({ x, y, width, height });
});

document.addEventListener("keydown", (e) => {
  if (e.key === "Escape") {
    window.bridge.cancelOverlay();
  }
});
